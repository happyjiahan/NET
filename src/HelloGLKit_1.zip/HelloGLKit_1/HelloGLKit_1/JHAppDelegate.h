//
//  JHAppDelegate.h
//  HelloGLKit_1
//
//  Created by lijiahan on 13-12-7.
//  Copyright (c) 2013年 blog.codingcoder.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface JHAppDelegate : UIResponder <UIApplicationDelegate, GLKViewDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
